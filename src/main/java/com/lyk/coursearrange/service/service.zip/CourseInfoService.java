package com.lyk.coursearrange.service;

import com.lyk.coursearrange.entity.CourseInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lequal
 * @since 2020-04-03
 */
public interface CourseInfoService extends IService<CourseInfo> {

}
