package com.lyk.coursearrange.service;

import com.lyk.coursearrange.entity.OnlineCourse;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lequal
 * @since 2020-06-04
 */
public interface OnlineCourseService extends IService<OnlineCourse> {

}
